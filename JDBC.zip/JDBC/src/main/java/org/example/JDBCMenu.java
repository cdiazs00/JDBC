package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class JDBCMenu {
    private int option;

    public JDBCMenu() {
        super();
    }

    public int mainMenu() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        do {
            System.out.println("MENÚ PRINCIPAL");
            System.out.println("1. Crea personajes");
            System.out.println("2. Crea estadísticas");
            System.out.println("3. Crea nacimientos");
            System.out.println("4. Añade datos de archivos");
            System.out.println("5. Muestra personajes");
            System.out.println("6. Muestra estadísticas");
            System.out.println("7. Muestra nacimientos");
            System.out.println("8. Muestra personajes por propiedad");
            System.out.println("9. Salir");
            System.out.print("Escoge una opción: ");
            try {
                option = Integer.parseInt(br.readLine());
            } catch (NumberFormatException | IOException e) {
                System.out.println("Valor no válido");
                e.printStackTrace();
            }
        } while (option != 1 && option != 2 && option != 3 && option != 5 && option != 6 && option != 7 && option != 8);

        return option;
    }
}
