package org.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class JDBCMain {
    public static void main(String[] args) throws IOException, SQLException {
        JDBCMenu menu = new JDBCMenu();

        ConnectionFactory connectionFactory = ConnectionFactory.getInstance();
        Connection c = connectionFactory.connect();

        CharacterController characterController = new CharacterController(c);

        int option = menu.mainMenu();
        while (option > 0 && option < 10) {
            switch (option) {
                case 1:
                    characterController.addCharacter_properties();
                    break;

                case 2:
                    characterController.addCharacter_stats();
                    break;

                case 3:
                    characterController.addCharacter_births();
                    break;

                case 4:
                    characterController.addFile("src/characters_births.csv", "characters_births");
                    characterController.addFile("src/characters_properties.csv", "characters_properties");
                    characterController.addFile("src/characters_stats.csv", "characters_stats");
                    break;

                case 5:
                    characterController.showCharacters_properties();
                    break;

                case 6:
                    characterController.showCharacters_stats();
                    break;

                case 7:
                    characterController.showCharacters_births();
                    break;

                case 8:
                    characterController.showCharacters_propertiesByProperty();
                    break;

                case 9:
                    System.exit(0);
                    break;

                default:
                    System.out.println("Introduce una de las opciones anteriores");
                    break;

            }
            option = menu.mainMenu();
        }
    }
}