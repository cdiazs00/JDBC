package org.example;

import java.io.*;
import java.sql.*;

/**
 * Controlador para la gestión de personajes en una base de datos.
 */
public class CharacterController {
    private final Connection connection;

    /**
     * Constructor que establece la conexión y ejecuta el archivo SQL para crear las tablas.
     *
     * @param connection La conexión a la base de datos.
     */
    public CharacterController(Connection connection) {
        this.connection = connection;
        //try {
        //executeSQLFromFile("src/main/resources/jdbc.sql", "properties");
        //executeSQLFromFile("src/main/resources/jdbc.sql", "stats");
        //executeSQLFromFile("src/main/resources/jdbc.sql", "births");
    } //catch (IOException | SQLException e) {
    //throw new RuntimeException("Error al ejecutar el archivo", e);
    //}
    //}

    /**
     * Método para agregar información de propiedades de un personaje a la base de datos.
     *
     * @throws SQLException Si hay un error al interactuar con la base de datos.
     */
    public void addCharacter_properties() throws SQLException {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            PreparedStatement pst = connection.prepareStatement("INSERT INTO properties(id, name, element, rarity, weapon, class) VALUES (?, ?, ?, ?, ?, ?)");

            System.out.print("Inserta id: ");
            int id = Integer.parseInt(br.readLine());
            System.out.print("Inserta nombre: ");
            String nombre = br.readLine();
            System.out.print("Inserta elemento: ");
            String elemento = br.readLine();
            System.out.print("Inserta rareza: ");
            String rareza = br.readLine();
            System.out.print("Inserta arma: ");
            String arma = br.readLine();
            System.out.print("Inserta clase: ");
            String clase = br.readLine();

            pst.setInt(1, id);
            pst.setString(2, nombre);
            pst.setString(3, elemento);
            pst.setString(4, rareza);
            pst.setString(5, arma);
            pst.setString(6, clase);
            pst.executeUpdate();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Método para agregar estadísticas de un personaje a la base de datos.
     *
     * @throws SQLException Si hay un error al interactuar con la base de datos.
     */
    public void addCharacter_stats() throws SQLException {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            PreparedStatement pst = connection.prepareStatement("INSERT INTO stats(id, hp, atk, def, food) VALUES (?, ?, ?, ?, ?)");

                System.out.print("Inserta id: ");
                int id = Integer.parseInt(br.readLine());
                System.out.print("Inserta HP: ");
                String hp = br.readLine();
                System.out.print("Inserta ATK: ");
                String atk = br.readLine();
                System.out.print("Inserta DEF: ");
                String def = br.readLine();
                System.out.print("Inserta comida: ");
                String comida = br.readLine();

                pst.setInt(1, id);
                pst.setString(2, hp);
                pst.setString(3, atk);
                pst.setString(4, def);
                pst.setString(5, comida);
                pst.executeUpdate();

            } catch(IOException e){
                e.printStackTrace();
            }
        }

    /**
     * Método para agregar información de nacimiento de un personaje a la base de datos.
     *
     * @throws SQLException Si hay un error al interactuar con la base de datos.
     */
    public void addCharacter_births() throws SQLException {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            PreparedStatement pst = connection.prepareStatement("INSERT INTO births(id, birthdate, region, constellation) VALUES (?, ?, ?, ?)");

            System.out.print("Inserta id: ");
            int id = Integer.parseInt(br.readLine());
            System.out.print("Inserta fecha de nacimiento: ");
            String fecha_nacimiento = br.readLine();
            System.out.print("Inserta región: ");
            String region = br.readLine();
            System.out.print("Inserta constelación: ");
            String constelacion = br.readLine();

            pst.setInt(1, id);
            pst.setString(2, fecha_nacimiento);
            pst.setString(3, region);
            pst.setString(4, constelacion);
            pst.executeUpdate();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Método para agregar información desde un archivo CSV a la base de datos.
     *
     * @param csvFilePath Ruta del archivo CSV.
     * @param tableName   Nombre de la tabla en la base de datos.
     * @throws IOException  Si hay un error al leer el archivo CSV.
     * @throws SQLException Si hay un error al interactuar con la base de datos.
     */
    public void addFile(String csvFilePath, String tableName) throws IOException, SQLException {
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty() && !line.startsWith("BEGIN") && !line.startsWith("SET") &&
                        !line.startsWith("DROP") && !line.startsWith("CREATE")) {
                    String[] data = line.split(",");
                    if (data.length > 0) {
                        addFile(tableName, data);
                    } else {
                        System.out.println("Formato de datos no válido en CSV: " + line);
                    }
                }
            }
        }
    }

    /**
     * Método privado para agregar información desde un archivo CSV a la base de datos.
     *
     * @param tableName Nombre de la tabla en la base de datos.
     * @param data      Datos a agregar.
     * @throws SQLException Si hay un error al interactuar con la base de datos.
     */
    private void addFile(String tableName, String[] data) throws SQLException {
        StringBuilder sqlBuilder = new StringBuilder("INSERT INTO " + tableName + " VALUES (");
        for (int i = 0; i < data.length; i++) {
            sqlBuilder.append("?");
            if (i < data.length - 1) {
                sqlBuilder.append(", ");
            }
        }
        sqlBuilder.append(")");

        try (PreparedStatement pst = connection.prepareStatement(sqlBuilder.toString())) {
            for (int i = 0; i < data.length; i++) {
                if (i == 0) {
                    pst.setInt(i + 1, Integer.parseInt(data[i]));
                } else {
                    pst.setString(i + 1, data[i]);
                }
            }
            pst.executeUpdate();
        }
    }

    /**
     * Método para mostrar información de propiedades de todos los personajes.
     *
     * @throws SQLException Si hay un error al interactuar con la base de datos.
     */
    public void showCharacters_properties() throws SQLException {
        String query = "SELECT * FROM properties";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                System.out.print(resultSet.getInt("id") + " ");
                System.out.print(resultSet.getString("name") + " ");
                System.out.print(resultSet.getString("element") + " ");
                System.out.print(resultSet.getString("rarity") + " ");
                System.out.print(resultSet.getString("weapon") + " ");
                System.out.print(resultSet.getString("class") + " ");
                System.out.println(" ");
            }
        }
    }

    /**
     * Método para mostrar información de estadísticas de todos los personajes.
     *
     * @throws SQLException Si hay un error al interactuar con la base de datos.
     */
    public void showCharacters_stats() throws SQLException {
        String query = "SELECT * FROM stats";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                System.out.print(resultSet.getInt("id") + " ");
                System.out.print(resultSet.getString("hp") + " ");
                System.out.print(resultSet.getString("atk") + " ");
                System.out.print(resultSet.getString("def") + " ");
                System.out.print(resultSet.getString("food") + " ");
                System.out.println(" ");
            }
        }
    }

    /**
     * Método para mostrar información de nacimiento de todos los personajes.
     *
     * @throws SQLException Si hay un error al interactuar con la base de datos.
     */
    public void showCharacters_births() throws SQLException {
        String query = "SELECT * FROM births";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                System.out.print(resultSet.getInt("id") + " ");
                System.out.print(resultSet.getString("birthdate") + " ");
                System.out.print(resultSet.getString("region") + " ");
                System.out.print(resultSet.getString("constellation") + " ");
                System.out.println(" ");
            }
        }
    }

    /**
     * Método para mostrar información de propiedades de personajes filtrados por una propiedad específica.
     *
     * @throws SQLException Si hay un error al interactuar con la base de datos.
     */
    public void showCharacters_propertiesByProperty() throws SQLException {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Selecciona la propiedad: ");
            String property = br.readLine();

            System.out.print("Ingresa el valor para la propiedad seleccionada: ");
            String value = br.readLine();

            String query = "SELECT * FROM properties WHERE " + property + " = ?";

            System.out.println(query);

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, value);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                System.out.print(resultSet.getInt("id") + " ");
                System.out.print(resultSet.getString("name") + " ");
                System.out.print(resultSet.getString("element") + " ");
                System.out.print(resultSet.getString("rarity") + " ");
                System.out.print(resultSet.getString("weapon") + " ");
                System.out.print(resultSet.getString("class") + " ");
                System.out.println(" ");
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Método para ejecutar instrucciones SQL desde un archivo.
     *
     * @param sqlFilePath Ruta del archivo SQL.
     * @param tableName   Nombre de la tabla en la base de datos.
     * @throws IOException  Si hay un error al leer el archivo SQL.
     * @throws SQLException Si hay un error al interactuar con la base de datos.
     */
    public void executeSQLFromFile(String sqlFilePath, String tableName) throws IOException, SQLException {
        String sqlContent = readSQLFile(sqlFilePath);
        sqlContent = sqlContent.replace("?", tableName);
        executeSQLStatements(connection, sqlContent);
    }

    /**
     * Método privado para leer el contenido de un archivo SQL.
     *
     * @param filePath Ruta del archivo SQL.
     * @return Contenido del archivo SQL.
     * @throws IOException Si hay un error al leer el archivo.
     */
    private String readSQLFile(String filePath) throws IOException {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        }
        return content.toString();
    }

    /**
     * Método privado para ejecutar instrucciones SQL.
     *
     * @param connection Conexión a la base de datos.
     * @param sqlContent Contenido SQL a ejecutar.
     * @throws SQLException Si hay un error al interactuar con la base de datos.
     */
    private void executeSQLStatements(Connection connection, String sqlContent) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            String[] statements = sqlContent.split(";");
            for (String sql : statements) {
                if (!sql.trim().isEmpty()) {
                    statement.execute(sql);
                }
            }
        }
    }
}