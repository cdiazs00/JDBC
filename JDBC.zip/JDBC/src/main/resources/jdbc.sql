BEGIN WORK;
SET TRANSACTION READ WRITE;

DROP TABLE IF EXISTS characters_properties CASCADE;
DROP TABLE IF EXISTS characters_stats;
DROP TABLE IF EXISTS characters_births;

CREATE TABLE characters_properties
(
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(50),
    element     VARCHAR(50),
    rarity      VARCHAR(50),
    weapon      VARCHAR(50),
    class       VARCHAR(50)
);

CREATE TABLE characters_stats
(
    id          INTEGER PRIMARY KEY,
    hp          VARCHAR(50),
    atk         VARCHAR(50),
    def         VARCHAR(50),
    food        VARCHAR(50),
    CONSTRAINT fk_character_stats FOREIGN KEY (id) REFERENCES characters_properties(id)
);

CREATE TABLE characters_births
(
    id              INTEGER PRIMARY KEY,
    birthdate       VARCHAR(50),
    region          VARCHAR(50),
    constellation   VARCHAR(50),
    CONSTRAINT fk_character_births FOREIGN KEY (id) REFERENCES characters_properties(id)
);